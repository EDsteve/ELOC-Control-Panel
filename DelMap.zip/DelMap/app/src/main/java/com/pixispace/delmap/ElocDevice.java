package com.pixispace.delmap;

public class ElocDevice {
    public final String plusCode;
    public final String name;
    public final double batteryVolts;
    public final String ranger;
    public final String time;
    public final double recTime;
    public final double accuracy;

    public ElocDevice(String plusCode, String name, double batteryVolts, String ranger, String time, double recTime, double accuracy) {
        this.plusCode = plusCode;
        this.name = name;
        this.batteryVolts = batteryVolts;
        this.ranger = ranger;
        this.time = time;
        this.recTime = recTime;
        this.accuracy = accuracy;
    }
}
