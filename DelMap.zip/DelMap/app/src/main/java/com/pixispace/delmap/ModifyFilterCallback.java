package com.pixispace.delmap;

public interface ModifyFilterCallback {
    void modify(String name, boolean select);
}
