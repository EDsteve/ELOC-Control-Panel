package com.pixispace.delmap;

// Copyright 2014 Google Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the 'License');
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an 'AS IS' BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/*
 * Convert locations to and from short codes.
 *
 * Open Location Codes are short, 10-11 character codes that can be used instead
 * of street addresses. The codes can be generated and decoded offline, and use
 * a reduced character set that minimises the chance of codes including words.
 *
 * Codes are able to be shortened relative to a nearby location. This means that
 * in many cases, only four to seven characters of the code are needed.
 * To recover the original code, the same location is not required, as long as
 * a nearby location is provided.
 *
 * Codes represent rectangular areas rather than points, and the longer the
 * code, the smaller the area. A 10 character code represents a 13.5x13.5
 * meter area (at the equator. An 11 character code represents approximately
 * a 2.8x3.5 meter area.
 *
 * Two encoding algorithms are used. The first 10 characters are pairs of
 * characters, one for latitude and one for latitude, using base 20. Each pair
 * reduces the area of the code by a factor of 400. Only even code lengths are
 * sensible, since an odd-numbered length would have sides in a ratio of 20:1.
 *
 * At position 11, the algorithm changes so that each character selects one
 * position from a 4x5 grid. This allows single-character refinements.
 *
 * Examples:
 *
 *   Encode a location, default accuracy:
 *   var code = OpenLocationCode.encode(47.365590, 8.524997);
 *
 *   Encode a location using one stage of additional refinement:
 *   var code = OpenLocationCode.encode(47.365590, 8.524997, 11);
 *
 *   Decode a full code:
 *   var coord = OpenLocationCode.decode(code);
 *   var msg = 'Center is ' + coord.latitudeCenter + ',' + coord.longitudeCenter;
 *
 *   Attempt to trim the first characters from a code:
 *   var shortCode = OpenLocationCode.shorten('8FVC9G8F+6X', 47.5, 8.5);
 *
 *   Recover the full code from a short code:
 *   var code = OpenLocationCode.recoverNearest('9G8F+6X', 47.4, 8.6);
 *   var code = OpenLocationCode.recoverNearest('8F+6X', 47.4, 8.6);
 */
// Translated to Java for ELOC Control Panel app
// todo: Make code compy with Apache license before public release
// todo: Original code from https://cdnjs.cloudflare.com/ajax/libs/openlocationcode/1.0.3/openlocationcode.js


import android.text.TextUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OpenLocationCode {
    // A separator used to break the code into two parts to aid memorability.
    private static final String SEPARATOR_ = "+";

    // The number of characters to place before the separator.
    private static final int SEPARATOR_POSITION_ = 8;

    // The character used to pad codes.
    private static final String PADDING_CHARACTER_ = "0";

    // The character set used to encode the values.
    private static final String CODE_ALPHABET_ = "23456789CFGHJMPQRVWX";

    // The base to use to convert numbers to/from.
    private static final int ENCODING_BASE_ = CODE_ALPHABET_.length();

    // The maximum value for latitude in degrees.
    private static final int LATITUDE_MAX_ = 90;

    // The maximum value for longitude in degrees.
    private static final int LONGITUDE_MAX_ = 180;

    // Size of the initial grid in degrees.
    private static final double GRID_SIZE_DEGREES_ = 0.000125;

    // Number of columns in the grid refinement method.
    private static final int GRID_COLUMNS_ = 4;

    // Number of rows in the grid refinement method.
    private static final int GRID_ROWS_ = 5;

    // Maxiumum code length using lat/lng pair encoding. The area of such a
    // code is approximately 13x13 meters (at the equator), and should be suitable
    // for identifying buildings. This excludes prefix and separator characters.
    private static final int PAIR_CODE_LENGTH_ = 10;

    // The resolution values in degrees for each position in the lat/lng pair
    // encoding. These give the place value of each position, and therefore the
    // dimensions of the resulting area.
    private static final double[] PAIR_RESOLUTIONS_ = new double[]{20.0, 1.0, 0.05, 0.0025, 0.000125};

    /**
     * Determines if a code is valid.
     * <p>
     * To be valid, all characters must be from the Open Location Code character
     * set with at most one separator. The separator can be in any even-numbered
     * position up to the eighth digit.
     *
     * @param code The string to check.
     * @return True if the string is a valid code.
     */
    private static boolean isValid(String code) {
        if ((code == null) || TextUtils.isEmpty(code)) {
            return false;
        }

        // The separator is required.
        if (!code.contains(SEPARATOR_)) {
            return false;
        }

        if (code.indexOf(SEPARATOR_) != code.lastIndexOf(SEPARATOR_)) {
            return false;
        }

        // Is it the only character?
        if (code.length() == 1) {
            return false;
        }

        // Is it in an illegal position?
        if ((code.indexOf(SEPARATOR_) > SEPARATOR_POSITION_) ||
                (code.indexOf(SEPARATOR_) % 2 == 1)) {
            return false;
        }

        // We can have an even number of padding characters before the separator,
        // but then it must be the final character.
        if (code.contains(PADDING_CHARACTER_)) {
            // Not allowed to start with them!
            if (code.indexOf(PADDING_CHARACTER_) == 0) {
                return false;
            }
            // There can only be one group and it must have even length.
            Pattern pattern = Pattern.compile("(" + PADDING_CHARACTER_ + "+)");
            Matcher matcher = pattern.matcher(code);
            boolean hasMatch = matcher.find();
            boolean hasMoreThanOneMatch = false;
            int firstMatchLength = 0;
            if (hasMatch) {
                firstMatchLength = matcher.group().length();
                hasMoreThanOneMatch = matcher.find();
            }
            if (
                    hasMoreThanOneMatch ||
                            firstMatchLength % 2 == 1 ||
                            firstMatchLength > SEPARATOR_POSITION_ - 2
            ) {
                return false;
            }
            // If the code is long enough to end with a separator, make sure it does.
            if (code.charAt(code.length() - 1) != SEPARATOR_.charAt(0)) {
                return false;
            }
        }
        // If there are characters after the separator, make sure there isn't just
        // one of them (not legal).
        if (code.length() - code.indexOf(SEPARATOR_) - 1 == 1) {
            return false;
        }

        // Strip the separator and any padding characters.
        code = code.replace(SEPARATOR_, "").replace(PADDING_CHARACTER_, "");

        // Check the code contains only valid characters.
        for (int i = 0, len = code.length(); i < len; i++) {
            String character = String.valueOf(code.toUpperCase().charAt(i));
            if ((!character.equals(SEPARATOR_)) && (!CODE_ALPHABET_.contains(character))) {
                return false;
            }
        }
        return true;
    }

    /**
     * Determines if a code is a valid short code.
     *
     * @param code The string to check.
     * @return True if the string can be produced by removing four or
     * more characters from the start of a valid code.
     */
    private static boolean isShort(String code) {
        // Check it's valid.
        if (!isValid(code)) {
            return false;
        }
        // If there are less characters than expected before the SEPARATOR.
        return (code.contains(SEPARATOR_)) &&
                (code.indexOf(SEPARATOR_) < SEPARATOR_POSITION_);
    }

    /**
     * Determines if a code is a valid full Open Location Code.
     *
     * @param code The string to check.
     * @return True if the code represents a valid latitude and longitude combination.
     */
    private static boolean isFull(String code) {
        if (!isValid(code)) {
            return false;
        }
        // If it's short, it's not full.
        if (isShort(code)) {
            return false;
        }

        // Work out what the first latitude character indicates for latitude.
        int firstLatValue = CODE_ALPHABET_.indexOf(code.toUpperCase().charAt(0)) * ENCODING_BASE_;
        if (firstLatValue >= LATITUDE_MAX_ * 2) {
            // The code would decode to a latitude of >= 90 degrees.
            return false;
        }
        if (code.length() > 1) {
            // Work out what the first longitude character indicates for longitude.
            int firstLngValue = CODE_ALPHABET_.indexOf(code.toUpperCase().charAt(1)) * ENCODING_BASE_;
            // The code would decode to a longitude of >= 180 degrees.
            return firstLngValue < LONGITUDE_MAX_ * 2;
        }
        return true;
    }

    /**
     * Decode either a latitude or longitude sequence.
     * <p>
     * This decodes the latitude or longitude sequence of a lat/lng pair encoding.
     * Starting at the character at position offset, every second character is
     * decoded and the value returned.
     *
     * @param code   A valid full OLC code, with the separator removed.
     * @param offset The character to start from.
     * @return An array of two numbers, representing the lower and
     * upper range in decimal degrees. These are in positive ranges and will
     * need to be corrected appropriately.
     */
    private static double[] decodePairsSequence(String code, int offset) {
        int i = 0;
        double value = 0;
        int codeLength = code.length();
        while (true) {
            int index = i * 2 + offset;
            if (index >= codeLength) {
                break;
            }
            value += CODE_ALPHABET_.indexOf(code.charAt(index)) * PAIR_RESOLUTIONS_[i];
            i += 1;
        }
        return new double[]{value, value + PAIR_RESOLUTIONS_[i - 1]};
    }

    /**
     * Decode an OLC code made up of lat/lng pairs.
     * <p>
     * This decodes an OLC code made up of alternating latitude and longitude
     * characters, encoded using base 20.
     *
     * @param code The code to decode, assumed to be a valid full code,
     *             but with the separator removed.
     * @return The code area object.
     */
    private static CodeArea decodePairs(String code) {
        // Get the latitude and longitude values. These will need correcting from
        // positive ranges.
        double[] latitude = decodePairsSequence(code, 0);
        double[] longitude = decodePairsSequence(code, 1);
        // Correct the values and set them into the CodeArea object.
        return new CodeArea(
                latitude[0] - LATITUDE_MAX_,
                longitude[0] - LONGITUDE_MAX_,
                latitude[1] - LATITUDE_MAX_,
                longitude[1] - LONGITUDE_MAX_,
                code.length()
        );
    }

    /**
     * Decode the grid refinement portion of an OLC code.
     *
     * @param code The grid refinement section of a code.
     * @return The area of the code.
     */
    private static CodeArea decodeGrid(String code) {
        double latitudeLo = 0.0;
        double longitudeLo = 0.0;
        double latPlaceValue = GRID_SIZE_DEGREES_;
        double lngPlaceValue = GRID_SIZE_DEGREES_;
        int i = 0;
        while (i < code.length()) {
            int codeIndex = CODE_ALPHABET_.indexOf(code.charAt(i));
            int row = (int) Math.floor((double) codeIndex / GRID_COLUMNS_);
            int col = codeIndex % GRID_COLUMNS_;

            latPlaceValue /= GRID_ROWS_;
            lngPlaceValue /= GRID_COLUMNS_;

            latitudeLo += row * latPlaceValue;
            longitudeLo += col * lngPlaceValue;
            i += 1;
        }
        return new CodeArea(
                latitudeLo,
                longitudeLo,
                latitudeLo + latPlaceValue,
                longitudeLo + lngPlaceValue,
                code.length()
        );
    }

    /**
     * Decodes an Open Location Code into its location coordinates.
     * <p>
     * Returns a CodeArea object that includes the coordinates of the bounding
     * box - the lower left, center and upper right.
     *
     * @param code The code to decode.
     * @return An object with the coordinates of the
     * area of the code.
     * @throws IllegalArgumentException If the code is not valid.
     */
    static CodeArea decode(String code) throws IllegalArgumentException {
        if (!isFull(code)) {
            throw new IllegalArgumentException("Passed Open Location Code is not a valid full code: " + code);

        }
        // Strip out separator character (we've already established the code is
        // valid so the maximum is one), padding characters and convert to upper
        // case.
        code = code.replace(SEPARATOR_, "")
                .replace(PADDING_CHARACTER_, "")
                .toUpperCase();
        // Decode the lat/lng pair component.
        CodeArea codeArea = decodePairs(code.substring(0, PAIR_CODE_LENGTH_));
        // If there is a grid refinement component, decode that.
        if (code.length() <= PAIR_CODE_LENGTH_) {
            return codeArea;
        }
        CodeArea gridArea = decodeGrid(code.substring(PAIR_CODE_LENGTH_));
        return new CodeArea(
                codeArea.latitudeLo + gridArea.latitudeLo,
                codeArea.longitudeLo + gridArea.longitudeLo,
                codeArea.latitudeLo + gridArea.latitudeHi,
                codeArea.longitudeLo + gridArea.longitudeHi,
                codeArea.codeLength + gridArea.codeLength
        );
    }

    public static class CodeArea {

        /**
         * The latitude of the SW corner.
         */
        final double latitudeLo;

        /**
         * The longitude of the SW corner in degrees.
         */
        final double longitudeLo;

        /**
         * The latitude of the NE corner in degrees.
         */
        final double latitudeHi;

        /**
         * The longitude of the NE corner in degrees.
         */
        final double longitudeHi;

        /**
         * The number of digits in the code.
         */
        final int codeLength;

        /**
         * The latitude of the center in degrees.
         */
        final double latitudeCenter;

        /**
         * The longitude of the center in degrees.
         */
        final double longitudeCenter;

        public CodeArea(double latitudeLo, double longitudeLo, double latitudeHi, double longitudeHi, int codeLength) {

            this.latitudeLo = latitudeLo;
            this.longitudeLo = longitudeLo;
            this.latitudeHi = latitudeHi;
            this.longitudeHi = longitudeHi;
            this.codeLength = codeLength;
            this.latitudeCenter = Math.min(
                    latitudeLo + (latitudeHi - latitudeLo) / 2,
                    LATITUDE_MAX_
            );
            this.longitudeCenter = Math.min(
                    longitudeLo + (longitudeHi - longitudeLo) / 2,
                    LONGITUDE_MAX_
            );
        }
    }
}
