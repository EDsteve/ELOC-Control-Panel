package com.pixispace.delmap;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pixispace.delmap.databinding.LayoutRangerFilterItemBinding;

public class RangerFilterItem extends RecyclerView.ViewHolder {
    private final LayoutRangerFilterItemBinding binding;

    public RangerFilterItem(@NonNull View itemView, ModifyFilterCallback callback) {
        super(itemView);
        binding = LayoutRangerFilterItemBinding.bind(itemView);

        binding.checkbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (callback != null) {
                callback.modify(binding.rangerNameTextView.getText().toString(), isChecked);
            }
        });
    }

    void setSelected(boolean b) {
        binding.checkbox.setChecked(b);
    }

    void setRangerName(String name) {
        binding.rangerNameTextView.setText(name);
    }
}
