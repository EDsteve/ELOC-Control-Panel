package com.pixispace.delmap;

import java.util.ArrayList;

public class Server {

    static ArrayList<ElocDevice> getElocDevices() {
        ArrayList<ElocDevice> devices = new ArrayList<>();
        devices.add(new ElocDevice("6P4G59P3+8J", "Eloc21", 3.19, "Nabila", "2022-10-17 11:02:22", 0.66, 6.4026637));
        devices.add(new ElocDevice("6P4G59P3+8H", "eloc24", 3.19, "Nabila", "2022-10-17 10:12:18", 0.00, 14.67471));
        devices.add(new ElocDevice("6P4G59P3+CJ", "ELOC11", 3.18, "Nabila", "2022-10-14 15:31:59", 0.00, 4.754922));
        devices.add(new ElocDevice("6P4G59P3+8H", "ELOC15", 3.07, "Nabila", "2022-10-17 10:42:23", 0.00, 19.279549));
        devices.add(new ElocDevice("6P4G59P3+8J", "ELOC23", 3.19, "Nabila", "2022-10-17 11:02:12", 0.39, 5.4770093));
        devices.add(new ElocDevice("6P4G59P3+8J", "ELOC3", 3.28, "Nabila", "2022-10-17 14:20:02", 0.00, 7.067978));
        devices.add(new ElocDevice("6P4G59P3+9J", "ELOC4", 3.34, "Nabila", "2022-10-18 08:07:22", 0.00, 4.9052777));
        devices.add(new ElocDevice("6MJWMRHV+8V", "ELOCed", 3.24, "ed", "2022-11-30 14:18:30", 0.00, 7.504));
        devices.add(new ElocDevice("6PQWH82P+75", "ELOC8", 3.32, "Valrelyn", "2022-12-11 07:52:33", 71.86, 3.7900925));
        devices.add(new ElocDevice("6PQWH82M+RC", "ELOC27", 3.33, "Valrelyn", "2022-12-11 08:01:37", 71.67, 7.4893017));
        devices.add(new ElocDevice("6PQWH84P+52", "eloc12", 3.36, "Valrelyn", "2022-12-11 08:37:18", 0.00, 4.1580195));
        devices.add(new ElocDevice("6PQWH84M+3X", "eloc22", 3.23, "Valrelyn", "2022-12-11 08:41:51", 167.15, 5.5667253));
        devices.add(new ElocDevice("6PQWG8W7+FM", "ELOC19", 3.27, "Valrelyn", "2022-12-11 09:13:58", 192.12, 3.8660934));
        devices.add(new ElocDevice("6PQWG8W8+Q3", "ELOC5", 3.18, "Valrelyn", "2022-12-11 09:17:09", 166.65, 5.3039255));
        devices.add(new ElocDevice("6PQWG8V6+GP", "ELOC26", 3.31, "Valrelyn", "2022-12-11 09:43:03", 193.75, 11.485308));
        devices.add(new ElocDevice("6PQWG8V7+W6", "ELOC6", 3.33, "Valrelyn", "2022-12-11 09:47:32", 71.29, 3.909063));
        return devices;
    }
}
