package com.pixispace.delmap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.pixispace.delmap.databinding.ActivityStartBinding;

public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityStartBinding binding = ActivityStartBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.showAllElocsButton.setOnClickListener(v -> {
            Intent intent = new Intent(StartActivity.this, MapActivity.class);
            startActivity(intent);
        });
    }
}