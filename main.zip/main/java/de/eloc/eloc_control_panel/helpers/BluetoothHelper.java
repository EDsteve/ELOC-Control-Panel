package de.eloc.eloc_control_panel.helpers;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Build;
import android.util.Log;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.Executors;

import de.eloc.eloc_control_panel.ng.interfaces.ListUpdateCallback;
import de.eloc.eloc_control_panel.ng.models.DeviceInfo;

public class BluetoothHelper {
/*
    public static boolean hasEmptyAdapter() {
        if (listAdapter != null) {
            return listAdapter.isEmpty();
        }
        return true; // Use empty as default state so app shows scan mode
    }





    public static boolean isAdapterInitialized() {
        return adapter != null;
    }





    public boolean isAdapterOn() {
        return adapter.getState() == BluetoothAdapter.STATE_ON;
    }



    public static DeviceInfo getDeviceInfo(int index) {
        if ((index >= 0) && (index < devices.size())) {
            BluetoothDevice device = devices.get(index);
            return DeviceInfo.fromDevice(device);
        }
        return DeviceInfo.getDefault();
    }

    public static void clearDevices() {
        devices.clear();
    }




*/

}