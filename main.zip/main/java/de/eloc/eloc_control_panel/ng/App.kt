package de.eloc.eloc_control_panel.ng

import android.app.Application

class App : Application() {

    override fun onCreate() {
        super.onCreate()
        mAppInstance = this
    }

    companion object {
        private lateinit var mAppInstance: App

        fun getInstance(): App = mAppInstance
    }

}
