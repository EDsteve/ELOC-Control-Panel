package de.eloc.eloc_control_panel.ng.activities

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import com.google.android.material.snackbar.Snackbar
import de.eloc.eloc_control_panel.R
import de.eloc.eloc_control_panel.ng.App

object ActivityHelper {
    fun openInstructionsUrl() {
        val app = App.getInstance()
        val url = app.getString(R.string.instructions_url)
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse(url)
        app.startActivity(intent)
    }

    fun showAlert(message: String) {
        AlertDialog.Builder(App.getInstance())
            .setCancelable(true)
            .setMessage(message)
            .setPositiveButton(android.R.string.ok) { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    fun showSnack(coordinator: CoordinatorLayout, message: String) {
        Snackbar
            .make(coordinator, message, Snackbar.LENGTH_LONG)
            .show()
    }

    fun hideKeyboard(activity: AppCompatActivity) {
        try {
            val binder = activity.currentFocus?.windowToken
            if (binder != null) {
                val manager =
                    activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager?
                manager?.hideSoftInputFromWindow(binder, 0)
            }
        } catch (_: Exception) {
            // It an error occurs trying to hide the keyboard,
            // just ignore the error without crashing app.
        }
    }
}