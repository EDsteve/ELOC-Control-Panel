package de.eloc.eloc_control_panel.ng.activities

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import de.eloc.eloc_control_panel.BuildConfig
import de.eloc.eloc_control_panel.R
import de.eloc.eloc_control_panel.SNTPClient
import de.eloc.eloc_control_panel.UploadFileAsync
import de.eloc.eloc_control_panel.activities.TerminalActivity
import de.eloc.eloc_control_panel.databinding.ActivityHomeBinding
import de.eloc.eloc_control_panel.databinding.PopupWindowBinding
import de.eloc.eloc_control_panel.ng.models.AppBluetoothManager
import de.eloc.eloc_control_panel.ng.models.AppPreferenceManager
import de.eloc.eloc_control_panel.ng.models.Constants
import de.eloc.eloc_control_panel.ng.models.DeviceAdapter
import de.eloc.eloc_control_panel.receivers.BluetoothScanReceiver
import java.io.*
import java.text.SimpleDateFormat
import java.util.*

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding
    private var rangerName = Constants.DEFAULT_RANGER_NAME
    private val receiver = BluetoothScanReceiver(::onListUpdated)
    private var gUploadEnabled = false
    private var gLastTimeDifferenceMillisecond = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setActionBar()
        initialize()
    }

    override fun onResume() {
        super.onResume()
        checkRangerName()
        registerScanReceiver()

        val hasNoDevices = binding.devicesRecyclerView.adapter?.itemCount == 0
        onListUpdated(hasNoDevices, false)
        if (hasNoDevices) {
            setBluetoothStatus(AppBluetoothManager.isAdapterOn())
        }
    }

    override fun onStop() {
        super.onStop()
        AppBluetoothManager.stopScan()
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.menu_devices, menu)
        val aboutItem = menu?.findItem(R.id.about)
        aboutItem?.title = BuildConfig.VERSION_NAME
        if (AppBluetoothManager.hasInitializedAdapter()) {
            menu?.findItem(R.id.bt_settings)?.isEnabled = false
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.browseStatusUpdates -> {
                val uri = Uri.parse("http://128.199.206.198/ELOC/files/?C=M;O=D")
                val browserIntent = Intent(Intent.ACTION_VIEW, uri)
                startActivity(browserIntent)
            }
            R.id.timeSync -> doSync(5000, true)
            R.id.setRangerName -> editRangerName()
            R.id.bt_settings -> {
                val intent = Intent()
                intent.action = Settings.ACTION_BLUETOOTH_SETTINGS
                startActivity(intent)
            }
        }
        return true
    }

    private fun doSync(timeoutMS: Int, showMessage: Boolean) {
        SNTPClient.getDate(
            timeoutMS,
            Calendar.getInstance().timeZone
        ) { _,
            _,
            googletimestamp,
            _
            ->
            run {
                if (googletimestamp == 0L) {
                    gUploadEnabled = false
                    invalidateOptionsMenu()
                    if (showMessage) {
                        ActivityHelper.showSnack(
                            binding.coordinator,
                            "sync FAILED\nCheck internet connection"
                        )
                    }
                } else {
                    gLastTimeDifferenceMillisecond = System.currentTimeMillis() - googletimestamp
                    AppPreferenceManager.saveTimestamps(
                        SystemClock.elapsedRealtime(),
                        googletimestamp
                    )
                    gUploadEnabled = true
                    invalidateOptionsMenu()
                    if (showMessage) {
                        val message =
                            getString(R.string.sync_template, gLastTimeDifferenceMillisecond)
                        ActivityHelper.showSnack(binding.coordinator, message)
                    }
                }
            }
        }
    }

    private fun registerScanReceiver() {
        val filter = AppBluetoothManager.getScanFilter()
        registerReceiver(receiver, filter)

        // Devices appear to be found after there is a brief delay..
        // Registration of receiver possible causes some kind of delay
        // or is possibly async?? More research needed. for now let's
        // have startScan() wait for 1 second before actually scanning.
        // be sure to apply the delay in startScan()
    }

    private fun setBluetoothStatus(isOn: Boolean) {
        var statusMessage = "<bluetooth is disabled>"
        if (isOn) {
            statusMessage = "<scanning for eloc devices>"
            startScan()
        }
        binding.status.text = statusMessage
    }

    private fun checkRangerName() {
        loadRangerName()
        if (TextUtils.isEmpty(rangerName) || rangerName == Constants.DEFAULT_RANGER_NAME) {
            editRangerName()
        }
    }

    private fun editRangerName() {
        val popupWindowBinding = PopupWindowBinding.inflate(layoutInflater)
        popupWindowBinding.rangerName.setText(rangerName)
        AlertDialog.Builder(this)
            .setCancelable(false)
            .setTitle("Input Your Ranger ID")
            .setView(popupWindowBinding.root)
            .setPositiveButton("SAVE") { dialog, _ ->
                run {
                    val editable = popupWindowBinding.rangerName.text
                    if (editable != null) {
                        dialog.dismiss()
                        val name = editable.toString().trim()
                        validateRangerName(name)
                    }
                }
            }
            .show()
    }

    private fun validateRangerName(name: String) {
        AppPreferenceManager.setRangerName(name.trim())
        loadRangerName()
        if (TextUtils.isEmpty(rangerName)) {
            checkRangerName()
        }
        ActivityHelper.hideKeyboard(this)
    }

    private fun setActionBar() {
        setSupportActionBar(binding.appbar.toolbar)
    }

    private fun initialize() {
        setListeners()
        setupListView()
        loadRangerName()
    }

    private fun setListeners() {
        binding.instructionsButton.setOnClickListener { ActivityHelper.openInstructionsUrl() }
        binding.refreshListButton.setOnClickListener { startScan() }
        binding.uploadElocStatusButton.setOnClickListener { uploadElocStatus() }
    }

    private fun loadRangerName() {
        rangerName = AppPreferenceManager.getRangerName().trim()
    }

    private fun setupListView() {
        val adapter = DeviceAdapter(::showDevice)
        binding.devicesRecyclerView.adapter = adapter
        binding.devicesRecyclerView.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
    }

    private fun showDevice(address: String) {
        AppBluetoothManager.stopScan()
        val intent = Intent(this, TerminalActivity::class.java)
        intent.putExtra(TerminalActivity.ARG_DEVICE, address)
        startActivity(intent)
    }

    private fun startScan() {
        // Important: see registerScanReceiver() for notes.
        val handler = Handler(Looper.getMainLooper())
        handler.postDelayed({
            AppBluetoothManager.scanAsync(::scanStarted)
        }, 1000)
    }

    private fun scanStarted(success: Boolean) {
        if (!success) {
            ActivityHelper.showAlert(getString(R.string.scan_error))
            AppBluetoothManager.stopScan()
        }
    }

    private fun fileToString(file: File): String {
        val text = StringBuilder()
        try {
            val br = BufferedReader(FileReader(file))
            while (true) {
                try {
                    val line = br.readLine()
                    text.append(line)
                    text.append('\n')
                } catch (_: IOException) {
                    break
                }
            }
            br.close()
        } catch (_: IOException) {
        }
        return text.toString()
    }

    private fun uploadElocStatus() {
        try {
            val files = filesDir.listFiles()
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)
            loadRangerName()
            val filestring = "update " + sdf.format(Date()) + ".upd"
            val fileout = OutputStreamWriter(openFileOutput(filestring, Context.MODE_PRIVATE))
            var filecounter = 0
            if (files != null) {
                for (file in files) {
                    if (!file.isDirectory) {
                        if (file.name.endsWith(".txt")) {
                            filecounter++
                            fileout.write(fileToString(file) + "\n\n\n")
                        }
                    }
                }

                fileout.write("\n\n\n end of updates")
                fileout.close()
                if (filecounter > 0) {
                    val filename = filesDir.absolutePath + "/" + filestring
                    UploadFileAsync.run(filename, filesDir, ::showSnack)
                } else {
                    ActivityHelper.showSnack(binding.coordinator, "Nothing to Upload!")
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun showSnack(message: String) {
        runOnUiThread {
            if (message.trim().isNotEmpty()) {
                ActivityHelper.showSnack(binding.coordinator, message)
            }
        }
    }

    private fun onListUpdated(isEmpty: Boolean, scanFinished: Boolean) {
        var showScanUI = isEmpty
        if (scanFinished) {
            showScanUI = false
        }
        if (showScanUI) {
            binding.devicesRecyclerView.visibility = View.GONE
            binding.initLayout.visibility = View.VISIBLE
            binding.uploadElocStatusButton.visibility = View.GONE
            binding.refreshListButton.visibility = View.GONE
        } else {
            binding.devicesRecyclerView.visibility = View.VISIBLE
            binding.initLayout.visibility = View.GONE
            binding.uploadElocStatusButton.visibility = View.VISIBLE
            binding.refreshListButton.visibility = View.VISIBLE
        }
        if (scanFinished) {
            AppBluetoothManager
            val hasEmptyAdapter = binding.devicesRecyclerView.adapter?.itemCount == 0
            if (hasEmptyAdapter) {
                AlertDialog.Builder(this)
                    .setCancelable(false)
                    .setTitle("Scan results")
                    .setMessage("No devices were found!")
                    .setNegativeButton(android.R.string.ok) { dialog, _ -> dialog.dismiss() }
                    .show()
            }
        }
    }
}