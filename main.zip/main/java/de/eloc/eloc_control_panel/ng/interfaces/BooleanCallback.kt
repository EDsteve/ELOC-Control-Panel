package de.eloc.eloc_control_panel.ng.interfaces

fun interface BooleanCallback {
    fun handler(b: Boolean)
}