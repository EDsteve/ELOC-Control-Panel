package de.eloc.eloc_control_panel.ng.interfaces

fun interface ListAdapterCallback {
    fun handler(s: String)
}