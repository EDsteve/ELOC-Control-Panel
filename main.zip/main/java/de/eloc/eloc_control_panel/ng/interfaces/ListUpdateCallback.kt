package de.eloc.eloc_control_panel.ng.interfaces

fun interface ListUpdateCallback {
    fun handler(isEmpty: Boolean, scanFinished: Boolean)
}
