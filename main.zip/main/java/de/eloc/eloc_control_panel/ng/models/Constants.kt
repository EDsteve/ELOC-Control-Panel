package de.eloc.eloc_control_panel.ng.models

object Constants {
    const val DEFAULT_RANGER_NAME = "notSet"
}