package de.eloc.eloc_control_panel.ng.models

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import de.eloc.eloc_control_panel.databinding.DeviceListItemBinding
import de.eloc.eloc_control_panel.ng.interfaces.ListAdapterCallback

class DeviceAdapter(private val callback: ListAdapterCallback) : RecyclerView.Adapter<DeviceViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DeviceViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = DeviceListItemBinding.inflate(inflater, parent, false)
        return DeviceViewHolder(binding.root)
    }

    override fun onBindViewHolder(holder: DeviceViewHolder, position: Int) {
        val device = AppBluetoothManager.getDevice(position)
        val info = DeviceInfo.fromDevice(device)
        holder.set(info, callback)
    }

    override fun getItemCount(): Int = AppBluetoothManager.getDeviceCount()
}