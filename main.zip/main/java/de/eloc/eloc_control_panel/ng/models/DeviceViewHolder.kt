package de.eloc.eloc_control_panel.ng.models

import android.view.View
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import de.eloc.eloc_control_panel.databinding.DeviceListItemBinding
import de.eloc.eloc_control_panel.ng.interfaces.ListAdapterCallback

class DeviceViewHolder(itemView: View) : ViewHolder(itemView) {
    private var binding: DeviceListItemBinding

    init {
        binding = DeviceListItemBinding.bind(itemView)
    }

    fun set(info: DeviceInfo, callback: ListAdapterCallback) {
        binding.text1.text = info.name
        binding.text2.text = info.address
        binding.root.setOnClickListener { callback.handler(info.address) }
    }
}